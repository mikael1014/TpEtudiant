package com.example.tppays;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.example.tppays.activity.EditPaysActivity;
import com.example.tppays.adapter.PaysAdapter;
import com.example.tppays.models.Pays;
import com.example.tppays.service.Config;
import com.example.tppays.service.PaysService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private PaysService paysService;
    private List<Pays> paysList = new ArrayList<>();
    private PaysAdapter paysAdapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewPays);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        chargementListe();
        paysService = Config.getApiClient().create(PaysService.class);
        paysService.getListePays().enqueue(new Callback<List<Pays>>() {
            @Override
            public void onResponse(Call<List<Pays>> call, Response<List<Pays>> response) {
                if (response.isSuccessful()) {
                    paysList = response.body();
                    chargementListe();

                }
            }

            @Override
            public void onFailure(Call<List<Pays>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void chargementListe() {
        paysAdapter = new PaysAdapter(paysList);
        recyclerView.setAdapter(paysAdapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mon_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(this, EditPaysActivity.class);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }
}