package com.example.tppays.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.tppays.MainActivity;
import com.example.tppays.R;
import com.example.tppays.models.Pays;
import com.example.tppays.service.Config;
import com.example.tppays.service.PaysService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditPaysActivity extends AppCompatActivity {
    private EditText edtNom, edtContinent, edtSuperficie, edtNombreHabitants;
    private PaysService paysService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_pays);

        paysService = Config.getApiClient().create(PaysService.class);

        edtNom = findViewById(R.id.edtNom);
        edtContinent = findViewById(R.id.edtContinent);
        edtNombreHabitants = findViewById(R.id.edtNbrHabitants);
        edtSuperficie = findViewById(R.id.edtSuperficie);
    }

    public void enregisterPays(View view) {
        Pays pays = new Pays();
        pays.setContinent(edtContinent.getText().toString());
        pays.setNom(edtNom.getText().toString());
        pays.setNombreHabitants(Long.parseLong(edtNombreHabitants.getText().toString()));
        pays.setSuperficie(Long.parseLong(edtSuperficie.getText().toString()));

        paysService.savePays(pays).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Intent intent = new Intent(getBaseContext(), MainActivity.class);
                    startActivity(intent);
                } else {
                    Log.e("Error code", String.valueOf(response.code()));
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

}