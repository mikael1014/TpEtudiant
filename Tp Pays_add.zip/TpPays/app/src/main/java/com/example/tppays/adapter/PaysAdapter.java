package com.example.tppays.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tppays.R;
import com.example.tppays.activity.DetailsPaysActivity;
import com.example.tppays.models.Pays;

import java.util.List;

public class PaysAdapter extends RecyclerView.Adapter<PaysAdapter.PaysViewHolder>{
    private final List<Pays> paysList;

    public PaysAdapter(List<Pays> paysList) {
        this.paysList = paysList;
    }

    @NonNull
    @Override
    public PaysAdapter.PaysViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_pays, parent, false);
        return new PaysViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PaysAdapter.PaysViewHolder holder, int position) {
        Pays pays = paysList.get(position);
        holder.tvNom.setText(pays.getNom());
        holder.tvContinent.setText(pays.getContinent());
        holder.itemView.setOnClickListener(view -> {
            Context context = view.getContext();
            Intent intent = new Intent(context, DetailsPaysActivity.class);
//            intent.putExtra("selectedPays", pays);
            intent.putExtra("idPays", pays.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return paysList.size();
    }

    public static class PaysViewHolder extends RecyclerView.ViewHolder{
        public TextView tvNom;
        public TextView tvContinent;

        public PaysViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNom = itemView.findViewById(R.id.tvLNom);
            tvContinent = itemView.findViewById(R.id.tvLContinent);
        }
    }
}
