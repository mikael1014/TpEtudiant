package com.example.tppays.models;

import java.io.Serializable;

public class Pays implements Serializable {
    private Long id;
    private String nom;
    private String continent;
    private Long superficie;
    private Long nombreHabitants;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public Long getSuperficie() {
        return superficie;
    }

    public void setSuperficie(Long superficie) {
        this.superficie = superficie;
    }

    public Long getNombreHabitants() {
        return nombreHabitants;
    }

    public void setNombreHabitants(Long nombreHabitants) {
        this.nombreHabitants = nombreHabitants;
    }
}
